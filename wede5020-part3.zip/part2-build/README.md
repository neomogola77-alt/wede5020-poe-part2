# NextGen Tennis Academy — Website (WEDE5020 POE)

**Student:** Neo Mogola (ST10522165) · **Group:** DIS Group 3
**Subject:** Web Development (WEDE5020) · **Current stage:** Part 3 — Enhancing Functionality and SEO

A responsive, multi-page marketing and enquiry website for a fictional high-performance tennis academy in Pretoria, built with semantic HTML5, one external stylesheet, and vanilla JavaScript (no build step).

**Live site:** _add deployed URL here (Netlify / GitHub Pages)_
**Repository:** _add GitHub repository link here before submitting to the LMS_

## Pages

| Page | File | Purpose |
|---|---|---|
| Home | `index.html` | Hero, programme previews with internal links, pillars, CTA |
| About | `about.html` | History, mission/vision, **session tabs**, values, staff, **lightbox gallery** |
| Services | `services.html` | **Dynamic programme finder (search/filter/sort + modal)**, junior/adult/private detail, pricing, **FAQ accordion** |
| Enquiry | `enquiry.html` | Validated enquiry form that returns a **cost + availability quote** (AJAX) |
| Contact | `contact.html` | Validated message form that **compiles an email**, **Leaflet map** of both facilities, hours |
| Not found | `404.html` | Friendly error page (Netlify serves it automatically) |

## Project structure

```
index.html  about.html  services.html  enquiry.html  contact.html  404.html
css/style.css
js/main.js       shared: nav, active link, reveal animation, accordion, tabs
js/forms.js      validation, enquiry quote (fetch), contact email builder
js/services.js   dynamic programme cards, search/filter/sort, modal
js/gallery.js    gallery lightbox
js/map.js        Leaflet map
data/programs.json   programme catalogue (prices, ages, availability)
images/          gallery images (placeholder SVG artwork) + favicon
robots.txt  sitemap.xml  _headers  netlify.toml
```

## Part 3 — Functionality

### Interactive elements
- **Accordion** (FAQ, `services.html`) — ARIA-compliant buttons, one panel open at a time.
- **Tabs** (`about.html`, "What a typical session looks like") — arrow/Home/End keyboard support.
- **Modal** (`services.html`) — programme details dialog with focus trap, Esc to close, focus returns to the trigger.
- **Interactive map** (`contact.html`) — Leaflet + OpenStreetMap tiles with a marker per facility, popups, "Show on map" buttons that `flyTo` the site, and a "Show both" reset.
- **Animations and transitions** — CSS scroll-reveal (IntersectionObserver), accordion/tab/modal fades, gallery hover zoom, button/card transitions. All respect `prefers-reduced-motion`.
- **Advanced DOM manipulation** — programme cards, modal content, quote results and the email preview are built with `createElement`/`textContent` (never `innerHTML` with user data), with event delegation on the programme grid.
- **Gallery with lightbox** (`about.html`) — click to enlarge, previous/next buttons, arrow keys, Esc, focus trap.

### Dynamic content
- `services.js` loads `data/programs.json` with `fetch` (AJAX) and renders 8 programme cards.
- **Search** (name, summary, category, inclusions), **category filter**, and **sort** (name, price low/high, youngest age, most places available), with a live result count and an empty state.

### Forms and JavaScript validation
- **enquiry.html** — name, email, SA phone number, participant age, programme, location, optional start date, message (500-char counter) and consent. After validation the page `fetch`es `programs.json` and shows the programme, **cost**, schedule, location and **availability**, plus warnings when the age is outside the programme range or the programme doesn't run at the chosen location.
- **contact.html** — name, email, optional phone, **message type**, subject and a full message (20–1000 characters). Once validated, the data is compiled into an email (To / Subject / Body preview) and the visitor sends it to `info@nextgentennis.co.za` through a `mailto:` link ("Open in email app").
- Validation rules: required fields, length limits, name characters, email format, South African phone format (`012 345 6789` / `+27 12 345 6789`), whole-number age 4–99, date not in the past and within 4 months, select/consent checks.
- HTML5 attributes (`required`, `type`, `minlength`, `maxlength`, `min`/`max`, `pattern`, `autocomplete`, `inputmode`) are in the markup; `novalidate` lets the JavaScript show consistent, inline error messages (`aria-invalid` + live regions). Fields validate on blur/change, then live as the user corrects them.
- The `action` attribute is not used because no server-side endpoint exists: the enquiry is processed client-side and the contact message leaves via the visitor's own email app.

> **Note:** `fetch` cannot read local JSON from `file://`. Open the site through a local server (e.g. VS Code Live Server) or the deployed URL; otherwise the forms/services show a clear error message.

## Part 3 — SEO

### Keyword research (target keywords per page)
| Page | Primary keyword | Secondary keywords |
|---|---|---|
| Home | tennis coaching Pretoria | tennis academy Pretoria, junior tennis lessons, adult tennis leagues |
| About | tennis academy Pretoria | tennis coaches Pretoria, ITF-certified coach |
| Services | tennis lessons Pretoria prices | junior tennis programmes, private tennis lessons, tennis membership |
| Enquiry | book trial tennis lesson | tennis lessons for kids Pretoria, enquire tennis academy |
| Contact | tennis courts Silver Lakes | tennis courts Waterkloof, tennis academy contact |

_(Keywords were chosen by reasoning about likely local search intent; they have not been verified with a keyword-research tool.)_

### On-page
- Unique `<title>` (~60–70 characters) and `<meta name="description">` (under 160 characters) on every page, with canonical, Open Graph and Twitter tags.
- One `<h1>` per page with logical H2/H3 structure; keywords used naturally in headings, eyebrows and body copy.
- Images: descriptive file names (`junior-coaching-session.svg`, `silver-lakes-tennis-courts.svg`), meaningful `alt` text, explicit `width`/`height`, `loading="lazy"`.
- Internal linking: programme cards on the home page link to the matching `services.html#…` sections; body copy links between About, Services, Enquiry and Contact; the footer lists all pages and programme anchors.
- Mobile-friendly: viewport meta tag, fluid layouts, relative units, breakpoints, touch-sized controls (no horizontal scrolling at 375 px).
- Structured data: `SportsActivityLocation` JSON-LD (address, phone, opening hours, geo) on the home and contact pages.

### Off-page (plan)
- **Backlinks:** list the academy on Tennis South Africa / Gauteng Tennis directories, local school sports newsletters, Pretoria business directories and local parenting blogs; offer coach guest articles ("5 drills for junior serve technique").
- **Social media:** Instagram, Facebook and YouTube links are in the footer (handles are placeholders — update them). Share match highlights, coach tips and the trial-lesson link with UTM tags.
- **Local SEO:** create and verify a Google Business Profile for each facility, keep name/address/phone identical to the website, ask members for reviews, and use the LocalBusiness-style structured data already on the site.

### Technical
- `robots.txt` (allows crawling, blocks `/data/`, points to the sitemap) and `sitemap.xml` (5 pages with priority and last modified).
- **Page speed:** scripts use `defer`; fonts use `display=swap` and `preconnect`; images are lazy-loaded with fixed dimensions; gallery art is lightweight SVG; long-cache headers for CSS/JS/images; no frameworks or large dependencies (only Leaflet, loaded on the contact page).
- **Security:** `_headers` (Netlify) sets `Content-Security-Policy`, `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` and HSTS; Leaflet is loaded with Subresource Integrity; external links use `rel="noopener noreferrer"`; user input is only written to the page with `textContent` (no XSS sink); no secrets or server code. HTTPS is provided by the hosting platform.

> **Before submitting:** replace the placeholder domain `https://nextgen-tennis.netlify.app` in `sitemap.xml`, `robots.txt`, the `canonical`/`og:url` tags and the JSON-LD with your real deployed URL (search the project for `nextgen-tennis.netlify.app`).

## Deployment

1. Push the project root to GitHub (`git add . && git commit -m "…" && git push`).
2. **Netlify:** "Add new site → Import from Git", choose the repo, publish directory `.`, no build command. (`_headers` and `netlify.toml` are picked up automatically.)
   **GitHub Pages:** Settings → Pages → deploy from the `main` branch root. (`_headers` is ignored there; the other security measures still apply.)
3. Paste the live URL at the top of this README, then submit the repository link on the LMS.

## Changelog

### Lecturer feedback from Part 2 — _to be completed by the student_
No marked feedback was available when this version was prepared. Add one entry per feedback point from the Part 2 mark sheet, in this form:

- **Feedback:** _quote or summarise the lecturer's comment_ → **Change made:** _what you edited, in which file(s), and why_

### 2026-11-02 — Part 3 (self-review fixes made while building Part 3)
- **Moved the remaining inline `<style>` blocks into `css/style.css`.** `enquiry.html` and `contact.html` still carried page-level `<style>` blocks after the Part 2 consolidation, which left the "single external stylesheet" rule incomplete. Their rules now live in `style.css`.
- **Fixed the active-page navigation highlight** in `main.js` so it also works on hosts that serve clean URLs (`/about`); added `aria-current="page"`.
- **Replaced the inline scroll shadow** (`header.style.boxShadow`) with a `.scrolled` class.
- **Fixed dead footer links:** `services.html#private` pointed at nothing; the Private Lessons card now has `id="private"`. Footer social icons (`href="#"`) now point to the platform URLs and open safely in a new tab.
- **Replaced the simulated enquiry submit** (a timeout with a generic thank-you) with real processing: validation, then a `fetch` of the catalogue and a cost/availability quote.
- **Strengthened validation** in `forms.js`: stricter SA phone format, name character check, integer age 4–99, date range check, `aria-invalid`, focus on the first invalid field, and consistent error handling for both forms. The previous Part 2 age rule (`> 0 and < 100`) conflicted with the form's own `min="4"`; both now agree. The membership option was split into Starter / Performance / Elite so it matches the pricing page.
- **Removed an inline SVG `style`** on the status icon and several inline styles on the enquiry side cards in favour of classes.

### 2026-11-02 — Part 3 (new features)
- **Interactive elements:** accordion (FAQ), tabs (session structure), modal (programme details), Leaflet map with markers and fly-to buttons, scroll-reveal and hover animations (respecting reduced-motion), advanced DOM building, gallery with lightbox.
- **Dynamic content:** new `data/programs.json` and `js/services.js` — programme cards loaded with `fetch`, with search, category filter, sorting, result count and empty state.
- **Forms:** added the validated message form to `contact.html` (compiles a `mailto:` email with a preview) and rebuilt the `enquiry.html` flow (adds a preferred start date field and message counter, shows the quote).
- **SEO:** unique titles/meta descriptions, canonical/Open Graph/Twitter tags, JSON-LD, keyword-focused headings and copy, internal links, descriptive image names and alt text, `robots.txt`, `sitemap.xml`, favicon, 404 page.
- **Performance & security:** `defer` on all scripts, `display=swap` fonts, lazy images with dimensions, caching and security headers (`_headers`), SRI on Leaflet, `rel="noopener noreferrer"`.
- **Structure:** JavaScript split by responsibility (`main`, `forms`, `services`, `gallery`, `map`) instead of one file.
- **Known limitations / placeholders:** gallery images are placeholder SVG artwork (swap in real photos with the same descriptive names); programme prices other than the three memberships are illustrative; map coordinates are approximate; the domain, social handles and repository link must be replaced.

### Part 2 changelog (previous pass)

#### 2026-09-18
- **Added a responsive image** (`about.html`, new "action photo" section): implemented with a `<picture>` element, a mobile-specific `<source>`, and a 3-candidate `srcset`/`sizes` set on the fallback `<img>`, satisfying the brief's requirement to demonstrate responsive image techniques. No photographic images existed anywhere in the Part 1 site (icons/decoration were inline SVG only), so this was a genuine gap rather than a refinement.
- **Consolidated all page-specific CSS into the single external stylesheet.** `services.html` previously carried its own `<style>` block (`.price-card`, `.program-row` rules) in the document `<head>`, in addition to the shared `css/style.css` link. Moved that block into `style.css` so every page now styles exclusively from one linked stylesheet, as the brief specifies.
- **Reduced inline styling in favour of the CSS cascade**, per the brief's explicit outcome to "take advantage of the cascading nature of CSS to style page elements with a minimum number of selectors":
  - Replaced repeated inline `background`/`border`/`color` combinations on `.card` elements (`index.html`, `about.html`) with reusable modifier classes: `.card-mist`, `.card-navy`, `.card-navy-soft`.
  - Replaced a repeated inline light-CTA-banner override (`services.html`) with a `.cta-banner-light` class.
  - Added a `.bg-navy p{ color: var(--muted-on-navy); }` rule so paragraph text on dark sections is legible by default, removing the need for a per-paragraph inline colour override (previously applied inconsistently — some navy sections used the override, some didn't).
  - Replaced a 3× repeated inline circular-avatar style block (`about.html`, coaching staff cards) with a single `.avatar-circle` class.
  - Replaced a 6× repeated inline flex/SVG pattern for checkmark list items (`services.html`, Adult Leagues and Private Lessons) with `.check-list` / `.check-icon` classes.
  - Removed an inline `color:var(--white)` on the footer brand text (present identically on all 5 pages) — it was already redundant, since `.brand` sets that colour and the span inherits it; also removed a matching redundant `margin-bottom` override on the footer brand link, now handled by a single `.footer-brand .brand` rule.
- **Net effect:** no visual or functional change to any page — this pass only reorganised *how* the existing design is expressed in CSS, so a future colour or spacing change only needs to happen in one place instead of being repeated across files.

### Part 1 submission
- Initial build of all 5 pages, design tokens, base/typography/layout styles, responsive breakpoints, and enquiry form validation logic.

## Testing

Tested manually in browser developer tools (device toolbar) at 1440, 1200, 820, 768, 414 and 375 px, and with automated headless-browser checks of the key flows:

- Services: 8 cards load; search, category filter and all five sort orders update the list and count; modal opens/closes (Esc); accordion allows one open panel.
- Enquiry: empty submit shows 6 errors; bad phone and past date are rejected; a valid submit shows the quote (programme, cost, schedule, availability).
- Contact: empty submit shows 5 errors; a valid submit builds the email preview and a correct `mailto:` link; if Leaflet cannot load, the page shows a fallback message instead of failing.
- About: tabs (click + arrow keys) and the lightbox (open, next, Esc).
- No console errors; no horizontal scrolling at 375 px.

> Screenshot evidence of desktop / tablet / mobile views to be added here before submission — create `docs/screenshots/` and reference each image, e.g. `![Home — desktop](docs/screenshots/home-desktop.png)`.

## References

- MDN Web Docs. *CSS Grid Layout.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs. *Flexbox.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- MDN Web Docs. *Responsive images.* https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- MDN Web Docs. *Using media queries.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
- MDN Web Docs. *CSS values and units.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Values_and_Units
- MDN Web Docs. *Fetch API.* https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
- MDN Web Docs. *Client-side form validation.* https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation
- MDN Web Docs. *Intersection Observer API.* https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
- MDN Web Docs. *Content Security Policy (CSP).* https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP
- W3C. *WAI-ARIA Authoring Practices Guide — Accordion, Tabs and Dialog patterns.* https://www.w3.org/WAI/ARIA/apg/patterns/
- W3C. *Web Content Accessibility Guidelines (WCAG) 2.1.* https://www.w3.org/TR/WCAG21/
- Leaflet. *Leaflet — an open-source JavaScript library for interactive maps.* https://leafletjs.com/
- OpenStreetMap contributors. *OpenStreetMap.* https://www.openstreetmap.org/copyright
- Google Search Central. *SEO Starter Guide; robots.txt and sitemaps documentation.* https://developers.google.com/search/docs
- Schema.org. *SportsActivityLocation.* https://schema.org/SportsActivityLocation
- Netlify Docs. *Custom headers.* https://docs.netlify.com/manage/routing/headers/
- GitHub Docs. *GitHub Pages.* https://docs.github.com/en/pages
- Google Fonts. *Inter* and *Manrope* typefaces. https://fonts.google.com/
