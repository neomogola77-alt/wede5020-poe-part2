// NextGen Tennis Academy — dynamic programme listing with search, filter, sort and detail modal
(function () {
  'use strict';
  var grid = document.getElementById('program-grid');
  if (!grid) { return; }

  var searchInput = document.getElementById('program-search');
  var categorySel = document.getElementById('program-category');
  var sortSel = document.getElementById('program-sort');
  var countEl = document.getElementById('program-count');
  var emptyEl = document.getElementById('program-empty');
  var resetBtn = document.getElementById('program-reset');
  var catalogue = null;

  var CATEGORY_LABELS = { junior: 'Junior', adult: 'Adult', private: 'Private', membership: 'Membership' };

  function money(n) { return 'R' + n.toLocaleString('en-ZA'); }
  function make(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }
  function ageText(p) { return p.ageMax >= 99 ? p.ageMin + '+' : p.ageMin + '\u2013' + p.ageMax; }

  function buildCard(p) {
    var card = make('article', 'card program-card');
    var top = make('div', 'program-card-top');
    top.appendChild(make('span', 'tag', CATEGORY_LABELS[p.category]));
    var avail = make('span', 'avail ' + (p.spotsLeft === 0 ? 'full' : p.spotsLeft <= 2 ? 'low' : 'ok'),
      p.spotsLeft === 0 ? 'Waiting list' : p.spotsLeft + ' place' + (p.spotsLeft === 1 ? '' : 's') + ' left');
    top.appendChild(avail);
    card.appendChild(top);
    card.appendChild(make('h3', null, p.name));
    card.appendChild(make('p', 'muted', p.summary));
    var meta = make('ul', 'program-meta');
    [['Ages', ageText(p)], ['Sessions', p.sessionsPerWeek + '/week \u00b7 ' + p.duration + ' min']].forEach(function (m) {
      var li = make('li'); li.appendChild(make('b', null, m[0] + ': ')); li.appendChild(document.createTextNode(m[1])); meta.appendChild(li);
    });
    card.appendChild(meta);
    var foot = make('div', 'program-card-foot');
    var price = make('div', 'program-price', money(p.price));
    price.appendChild(make('span', null, ' / ' + p.unit));
    foot.appendChild(price);
    var btn = make('button', 'btn btn-outline-navy btn-sm', 'View details');
    btn.type = 'button';
    btn.setAttribute('data-id', p.id);
    foot.appendChild(btn);
    card.appendChild(foot);
    return card;
  }

  function currentList() {
    var q = searchInput.value.trim().toLowerCase();
    var cat = categorySel.value;
    var list = catalogue.programs.filter(function (p) {
      var hay = (p.name + ' ' + p.summary + ' ' + p.category + ' ' + p.details.join(' ')).toLowerCase();
      return (cat === 'all' || p.category === cat) && (q === '' || hay.indexOf(q) !== -1);
    });
    var sort = sortSel.value;
    list.sort(function (a, b) {
      if (sort === 'price-asc') { return a.price - b.price; }
      if (sort === 'price-desc') { return b.price - a.price; }
      if (sort === 'age') { return a.ageMin - b.ageMin; }
      if (sort === 'availability') { return b.spotsLeft - a.spotsLeft; }
      return a.name.localeCompare(b.name);
    });
    return list;
  }

  function render() {
    var list = currentList();
    grid.textContent = '';
    list.forEach(function (p) { grid.appendChild(buildCard(p)); });
    countEl.textContent = 'Showing ' + list.length + ' of ' + catalogue.programs.length + ' programmes';
    emptyEl.hidden = list.length !== 0;
  }

  /* ---------- Modal ---------- */
  var modal = document.getElementById('program-modal');
  var lastTrigger = null;
  function openModal(p, trigger) {
    lastTrigger = trigger;
    document.getElementById('modal-title').textContent = p.name;
    document.getElementById('modal-summary').textContent = p.summary;
    var ul = document.getElementById('modal-details'); ul.textContent = '';
    p.details.forEach(function (d) { ul.appendChild(make('li', null, d)); });
    var facts = document.getElementById('modal-facts'); facts.textContent = '';
    [['Price', money(p.price) + ' per ' + p.unit], ['Ages', ageText(p)], ['Schedule', p.days],
     ['Location', p.locations.map(function (k) { return catalogue.locations[k]; }).join(' / ')],
     ['Availability', p.spotsLeft ? p.spotsLeft + ' place(s) open' : 'Full \u2014 waiting list']].forEach(function (f) {
      facts.appendChild(make('dt', null, f[0])); facts.appendChild(make('dd', null, f[1]));
    });
    document.getElementById('modal-enquire').setAttribute('href', 'enquiry.html');
    modal.hidden = false;
    document.body.classList.add('modal-open');
    modal.querySelector('.modal-close').focus();
  }
  function closeModal() {
    modal.hidden = true;
    document.body.classList.remove('modal-open');
    if (lastTrigger) { lastTrigger.focus(); }
  }
  modal.addEventListener('click', function (e) {
    if (e.target === modal || e.target.closest('.modal-close')) { closeModal(); }
  });
  document.addEventListener('keydown', function (e) {
    if (modal.hidden) { return; }
    if (e.key === 'Escape') { closeModal(); }
    if (e.key === 'Tab') {                         // keep focus inside the dialog
      var f = modal.querySelectorAll('button, a[href]');
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  grid.addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-id]'); if (!btn) { return; }
    var p = catalogue.programs.filter(function (x) { return x.id === btn.getAttribute('data-id'); })[0];
    if (p) { openModal(p, btn); }
  });

  /* ---------- Wire controls & load data (AJAX) ---------- */
  [searchInput, categorySel, sortSel].forEach(function (c) {
    c.addEventListener(c === searchInput ? 'input' : 'change', function () { if (catalogue) { render(); } });
  });
  resetBtn.addEventListener('click', function () {
    searchInput.value = ''; categorySel.value = 'all'; sortSel.value = 'name'; render(); searchInput.focus();
  });

  var loading = document.getElementById('program-loading');
  fetch('data/programs.json', { headers: { 'Accept': 'application/json' } })
    .then(function (r) { if (!r.ok) { throw new Error('HTTP ' + r.status); } return r.json(); })
    .then(function (data) { catalogue = data; loading.hidden = true; render(); })
    .catch(function () {
      loading.textContent = 'Programmes could not be loaded. If you opened this file directly from your computer, please view it through a local server (e.g. VS Code Live Server) or the deployed site.';
      loading.classList.add('load-error');
    });
})();
