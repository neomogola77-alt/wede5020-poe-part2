// NextGen Tennis Academy — shared behaviour (all pages)
document.addEventListener('DOMContentLoaded', function () {

  /* Mobile nav toggle */
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var isOpen = links.classList.toggle('open');
      toggle.classList.toggle('open', isOpen);
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    links.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        links.classList.remove('open');
        toggle.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* Highlight current page in nav.
     Strips ".html" so it also works on hosts that serve clean URLs (/about). */
  var current = (window.location.pathname.split('/').pop() || 'index').replace(/\.html$/, '') || 'index';
  document.querySelectorAll('.nav-links a').forEach(function (a) {
    var href = (a.getAttribute('href') || '').replace(/\.html$/, '');
    if (href === current) {
      a.classList.add('active');
      a.setAttribute('aria-current', 'page');
    }
  });

  /* Sticky header shadow on scroll (class toggle instead of inline style) */
  var header = document.querySelector('.site-header');
  if (header) {
    var onScroll = function () { header.classList.toggle('scrolled', window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* Scroll-reveal animation (respects reduced-motion preference) */
  document.documentElement.classList.add('js-ready');
  var revealEls = document.querySelectorAll('.reveal');
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (revealEls.length) {
    if ('IntersectionObserver' in window && !reduceMotion) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            io.unobserve(entry.target);
            (function (t) { setTimeout(function () { t.style.transitionDelay = ''; }, 1200); })(entry.target);
          }
        });
      }, { threshold: 0.12 });
      revealEls.forEach(function (el, i) {
        el.style.transitionDelay = (i % 4) * 70 + 'ms';
        io.observe(el);
      });
    } else {
      revealEls.forEach(function (el) { el.classList.add('in-view'); });
    }
  }

  /* ---------- Accordion (FAQ) ---------- */
  document.querySelectorAll('.accordion').forEach(function (acc) {
    var buttons = acc.querySelectorAll('.accordion-trigger');
    buttons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var expanded = btn.getAttribute('aria-expanded') === 'true';
        // only one panel open at a time
        buttons.forEach(function (other) {
          other.setAttribute('aria-expanded', 'false');
          document.getElementById(other.getAttribute('aria-controls')).hidden = true;
        });
        if (!expanded) {
          btn.setAttribute('aria-expanded', 'true');
          document.getElementById(btn.getAttribute('aria-controls')).hidden = false;
        }
      });
    });
  });

  /* ---------- Tabs ---------- */
  document.querySelectorAll('.tabs').forEach(function (tabs) {
    var tabBtns = Array.prototype.slice.call(tabs.querySelectorAll('[role="tab"]'));
    function activate(btn, focus) {
      tabBtns.forEach(function (b) {
        var on = b === btn;
        b.setAttribute('aria-selected', on ? 'true' : 'false');
        b.tabIndex = on ? 0 : -1;
        document.getElementById(b.getAttribute('aria-controls')).hidden = !on;
      });
      if (focus) { btn.focus(); }
    }
    tabBtns.forEach(function (btn, i) {
      btn.addEventListener('click', function () { activate(btn, false); });
      btn.addEventListener('keydown', function (e) {
        var idx = null;
        if (e.key === 'ArrowRight') { idx = (i + 1) % tabBtns.length; }
        if (e.key === 'ArrowLeft') { idx = (i - 1 + tabBtns.length) % tabBtns.length; }
        if (e.key === 'Home') { idx = 0; }
        if (e.key === 'End') { idx = tabBtns.length - 1; }
        if (idx !== null) { e.preventDefault(); activate(tabBtns[idx], true); }
      });
    });
  });
});
