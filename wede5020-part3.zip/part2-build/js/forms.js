// NextGen Tennis Academy — form validation, enquiry processing (AJAX) and contact email builder
(function () {
  'use strict';

  var CONTACT_RECIPIENT = 'info@nextgentennis.co.za';   // recipient used by the contact form's email
  var PROGRAMS_URL = 'data/programs.json';

  /* ---------- Shared validation rules ---------- */
  var rules = {
    fullName: function (v) {
      v = v.trim();
      if (v.length < 2) { return 'Please enter your full name (at least 2 characters).'; }
      if (v.length > 60) { return 'Name must be 60 characters or fewer.'; }
      if (!/^[A-Za-zÀ-ÿ' \-.]+$/.test(v)) { return 'Names can only contain letters, spaces, hyphens and apostrophes.'; }
      return true;
    },
    email: function (v) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Please enter a valid email address, e.g. name@example.com.';
    },
    phone: function (v, el) {
      v = v.trim();
      if (v === '' && !el.required) { return true; }
      // South African numbers: 0XX XXX XXXX or +27 XX XXX XXXX (spaces/dashes allowed)
      var digits = v.replace(/[\s\-()]/g, '');
      return /^(\+27|0027|0)[1-9][0-9]{8}$/.test(digits) || 'Enter a valid South African number, e.g. 012 345 6789 or +27 12 345 6789.';
    },
    participantAge: function (v) {
      var n = Number(v);
      if (v.trim() === '' || isNaN(n)) { return 'Please enter the participant\u2019s age.'; }
      if (n % 1 !== 0 || n < 4 || n > 99) { return 'Age must be a whole number between 4 and 99.'; }
      return true;
    },
    program: function (v) { return v !== '' || 'Please select a program.'; },
    startDate: function (v) {
      if (v === '') { return true; }                      // optional field
      var d = new Date(v + 'T00:00:00');
      var today = new Date(); today.setHours(0, 0, 0, 0);
      var max = new Date(today); max.setDate(max.getDate() + 120);
      if (isNaN(d.getTime())) { return 'Please enter a valid date.'; }
      if (d < today) { return 'Please choose today or a future date.'; }
      if (d > max) { return 'Please choose a date within the next 4 months.'; }
      return true;
    },
    messageType: function (v) { return v !== '' || 'Please choose the type of message.'; },
    subject: function (v) {
      v = v.trim();
      if (v.length < 3) { return 'Please add a short subject (at least 3 characters).'; }
      return v.length <= 80 || 'Subject must be 80 characters or fewer.';
    },
    message: function (v, el) {
      v = v.trim();
      var min = parseInt(el.getAttribute('minlength') || '0', 10);
      var max = parseInt(el.getAttribute('maxlength') || '0', 10);
      if (min && v.length < min) { return 'Please write at least ' + min + ' characters (currently ' + v.length + ').'; }
      if (max && v.length > max) { return 'Message must be ' + max + ' characters or fewer.'; }
      return true;
    },
    consent: function (v, el) { return el.checked || 'Please tick the box to continue.'; }
  };

  function wrapOf(el) { return el.closest('.field'); }

  function showError(el, msg) {
    var wrap = wrapOf(el); if (!wrap) { return; }
    wrap.classList.add('error');
    el.setAttribute('aria-invalid', 'true');
    var m = wrap.querySelector('.error-msg'); if (m) { m.textContent = msg; }
  }
  function clearError(el) {
    var wrap = wrapOf(el); if (!wrap) { return; }
    wrap.classList.remove('error');
    el.removeAttribute('aria-invalid');
    var m = wrap.querySelector('.error-msg'); if (m) { m.textContent = ''; }
  }
  function validateField(el) {
    var rule = rules[el.name]; if (!rule) { return true; }
    var value = el.type === 'checkbox' ? el.checked : el.value;
    var result = rule(value, el);
    if (result === true) { clearError(el); return true; }
    showError(el, result); return false;
  }

  function wireValidation(form) {
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!rules[el.name]) { return; }
      var evt = (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'date') ? 'change' : 'blur';
      el.addEventListener(evt, function () { validateField(el); });
      el.addEventListener('input', function () {
        var w = wrapOf(el);
        if (w && w.classList.contains('error')) { validateField(el); }
      });
    });
    // live character counters
    form.querySelectorAll('textarea[maxlength]').forEach(function (ta) {
      var counter = form.querySelector('[data-counter-for="' + ta.id + '"]');
      if (!counter) { return; }
      var update = function () { counter.textContent = ta.value.length + ' / ' + ta.getAttribute('maxlength'); };
      ta.addEventListener('input', update); update();
    });
  }

  function validateAll(form) {
    var ok = true, firstBad = null;
    Array.prototype.forEach.call(form.elements, function (el) {
      if (rules[el.name] && !validateField(el)) {
        ok = false; if (!firstBad) { firstBad = el; }
      }
    });
    if (firstBad) { firstBad.focus(); }
    return ok;
  }

  function setStatus(box, type, text) {
    box.classList.remove('show', 'success', 'fail');
    var span = box.querySelector('span');
    span.textContent = text;
    box.classList.add('show', type);
    box.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function money(n) { return 'R' + n.toLocaleString('en-ZA'); }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }

  /* ---------- Enquiry form ---------- */
  var enquiry = document.getElementById('enquiry-form');
  if (enquiry) {
    var status = document.getElementById('form-status');
    var result = document.getElementById('enquiry-result');
    wireValidation(enquiry);

    // restrict the date picker to today onwards
    var dateInput = document.getElementById('startDate');
    if (dateInput) { dateInput.min = new Date().toISOString().split('T')[0]; }

    enquiry.addEventListener('submit', function (e) {
      e.preventDefault();
      status.classList.remove('show');
      result.hidden = true;

      if (!validateAll(enquiry)) {
        setStatus(status, 'fail', 'Please correct the highlighted fields and try again.');
        return;
      }

      var btn = enquiry.querySelector('button[type="submit"]');
      var data = {
        name: enquiry.fullName.value.trim(),
        age: Number(enquiry.participantAge.value),
        program: enquiry.program.value,
        location: enquiry.location.value,
        startDate: enquiry.startDate.value
      };
      btn.disabled = true; btn.textContent = 'Checking availability\u2026';

      // AJAX: load programme pricing and availability without reloading the page
      fetch(PROGRAMS_URL, { headers: { 'Accept': 'application/json' } })
        .then(function (res) {
          if (!res.ok) { throw new Error('HTTP ' + res.status); }
          return res.json();
        })
        .then(function (catalogue) {
          renderEnquiryResult(result, catalogue, data);
          setStatus(status, 'success', 'Thank you, ' + data.name.split(' ')[0] + ' \u2014 your enquiry has been received. See your quote below.');
          enquiry.reset();
          enquiry.querySelectorAll('[data-counter-for]').forEach(function (c) { c.textContent = '0 / ' + c.getAttribute('data-max'); });
          result.hidden = false;
          result.scrollIntoView({ behavior: 'smooth', block: 'start' });
        })
        .catch(function () {
          setStatus(status, 'fail', 'We could not load pricing right now. Please try again, or email ' + CONTACT_RECIPIENT + '. (If you opened this file directly from your computer, run it through a local server or the deployed site.)');
        })
        .then(function () { btn.disabled = false; btn.textContent = 'Submit Enquiry'; });
    });
  }

  function renderEnquiryResult(box, catalogue, d) {
    box.textContent = '';
    var program = catalogue.programs.filter(function (p) { return p.id === d.program; })[0];
    box.appendChild(el('h3', null, 'Your enquiry summary'));

    if (!program) {
      box.appendChild(el('p', null, 'You told us you\u2019re not sure yet \u2014 that\u2019s fine. A coach will recommend the best-fit programme for a ' + d.age + '-year-old after a short call.'));
      box.appendChild(el('p', 'muted', 'Browse all programmes and prices on the Services page.'));
      return;
    }

    var ageOk = d.age >= program.ageMin && d.age <= program.ageMax;
    var locKeys = program.locations;
    var locOk = d.location === 'no-preference' || locKeys.indexOf(d.location) !== -1;

    var list = el('dl', 'result-list');
    function row(label, value) { list.appendChild(el('dt', null, label)); list.appendChild(el('dd', null, value)); }
    row('Programme', program.name);
    row('Cost', money(program.price) + ' per ' + program.unit + ' (indicative)');
    row('Schedule', program.days + ' \u00b7 ' + program.sessionsPerWeek + ' session(s) per week \u00b7 ' + program.duration + ' min');
    row('Location', locKeys.map(function (k) { return catalogue.locations[k]; }).join(' / '));
    row('Availability', program.spotsLeft > 0 ? program.spotsLeft + ' place(s) currently open' : 'Currently full \u2014 you will be added to the waiting list');
    if (d.startDate) { row('Requested start', new Date(d.startDate + 'T00:00:00').toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' })); }
    box.appendChild(list);

    if (!ageOk) {
      box.appendChild(el('p', 'result-note warn', 'Heads-up: this programme is designed for ages ' + program.ageMin + '\u2013' + (program.ageMax >= 99 ? '99' : program.ageMax) + '. A coach will confirm the best group for a ' + d.age + '-year-old.'));
    }
    if (!locOk) {
      box.appendChild(el('p', 'result-note warn', 'This programme runs at ' + locKeys.map(function (k) { return catalogue.locations[k]; }).join(' / ') + ', not your preferred location.'));
    }
    if (program.spotsLeft === 1) {
      box.appendChild(el('p', 'result-note', 'Only one place left \u2014 we recommend booking a trial soon.'));
    }
    box.appendChild(el('p', 'muted', 'Prices are indicative; your final rate is confirmed in the enrolment contract.'));
  }

  /* ---------- Contact form → compiled email ---------- */
  var contact = document.getElementById('contact-form');
  if (contact) {
    var cStatus = document.getElementById('contact-status');
    var preview = document.getElementById('email-preview');
    wireValidation(contact);

    contact.addEventListener('submit', function (e) {
      e.preventDefault();
      cStatus.classList.remove('show');
      preview.hidden = true;

      if (!validateAll(contact)) {
        setStatus(cStatus, 'fail', 'Please correct the highlighted fields and try again.');
        return;
      }

      var typeLabel = contact.messageType.options[contact.messageType.selectedIndex].text;
      var subject = '[' + typeLabel + '] ' + contact.subject.value.trim();
      var body = [
        'Hello NextGen Tennis Academy,',
        '',
        contact.message.value.trim(),
        '',
        '\u2014\u2014\u2014',
        'Name: ' + contact.fullName.value.trim(),
        'Email: ' + contact.email.value.trim(),
        'Phone: ' + (contact.phone.value.trim() || 'not provided'),
        'Message type: ' + typeLabel
      ].join('\r\n');

      var href = 'mailto:' + CONTACT_RECIPIENT + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);

      document.getElementById('preview-to').textContent = CONTACT_RECIPIENT;
      document.getElementById('preview-subject').textContent = subject;
      document.getElementById('preview-body').textContent = body;
      document.getElementById('send-email').setAttribute('href', href);
      preview.hidden = false;
      setStatus(cStatus, 'success', 'Your email is ready. Review it below, then press \u201cOpen in email app\u201d to send it.');
      preview.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });

    var editBtn = document.getElementById('edit-email');
    if (editBtn) {
      editBtn.addEventListener('click', function () {
        preview.hidden = true;
        cStatus.classList.remove('show');
        contact.fullName.focus();
      });
    }
  }
})();
