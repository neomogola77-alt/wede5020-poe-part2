// NextGen Tennis Academy — interactive facilities map (Leaflet + OpenStreetMap tiles)
(function () {
  'use strict';
  var mapEl = document.getElementById('facility-map');
  if (!mapEl) { return; }
  if (typeof L === 'undefined') {
    mapEl.innerHTML = '<p class="map-fallback">The interactive map could not be loaded. Please check your connection, or use the addresses below.</p>';
    return;
  }

  // Approximate coordinates \u2014 confirm against the real court locations before publishing.
  var sites = {
    primary:   { name: 'Silver Lakes Tennis Centre', lat: -25.8000, lng: 28.3990, note: 'Primary facility \u00b7 Mon\u2013Fri 06:00\u201320:00, Sat 07:00\u201314:00' },
    secondary: { name: 'Waterkloof Courts',          lat: -25.7790, lng: 28.2400, note: 'Secondary facility \u00b7 Tue\u2013Fri 14:00\u201320:00, Sat\u2013Sun 08:00\u201313:00' }
  };

  var map = L.map(mapEl, { scrollWheelZoom: false }).setView([-25.79, 28.32], 11);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);

  var markers = {};
  Object.keys(sites).forEach(function (key) {
    var s = sites[key];
    var popup = document.createElement('div');
    var h = document.createElement('strong'); h.textContent = s.name;
    var p = document.createElement('p'); p.textContent = s.note; p.style.margin = '6px 0 0';
    popup.appendChild(h); popup.appendChild(p);
    markers[key] = L.marker([s.lat, s.lng], { title: s.name, alt: s.name }).addTo(map).bindPopup(popup);
  });
  map.fitBounds([[sites.primary.lat, sites.primary.lng], [sites.secondary.lat, sites.secondary.lng]], { padding: [50, 50] });

  // Enable wheel-zoom only after the user interacts with the map
  map.on('focus click', function () { map.scrollWheelZoom.enable(); });
  map.on('blur', function () { map.scrollWheelZoom.disable(); });

  // "Show on map" buttons in the facility cards (DOM \u2192 map interaction)
  document.querySelectorAll('[data-show-site]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var key = btn.getAttribute('data-show-site');
      map.flyTo([sites[key].lat, sites[key].lng], 15, { duration: 1.2 });
      markers[key].openPopup();
      mapEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });
  var all = document.getElementById('map-show-all');
  if (all) {
    all.addEventListener('click', function () {
      map.fitBounds([[sites.primary.lat, sites.primary.lng], [sites.secondary.lat, sites.secondary.lng]], { padding: [50, 50] });
      map.closePopup();
    });
  }
})();
