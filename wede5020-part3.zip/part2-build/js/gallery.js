// NextGen Tennis Academy — gallery with accessible lightbox
(function () {
  'use strict';
  var items = Array.prototype.slice.call(document.querySelectorAll('.gallery-item'));
  var box = document.getElementById('lightbox');
  if (!items.length || !box) { return; }

  var img = box.querySelector('.lightbox-img');
  var cap = box.querySelector('.lightbox-caption');
  var index = 0, lastTrigger = null;

  function show(i) {
    index = (i + items.length) % items.length;
    var a = items[index];
    img.src = a.getAttribute('href');
    img.alt = a.querySelector('img').alt;
    cap.textContent = (index + 1) + ' / ' + items.length + ' \u2014 ' + a.getAttribute('data-caption');
  }
  function open(i, trigger) {
    lastTrigger = trigger; show(i);
    box.hidden = false; document.body.classList.add('modal-open');
    box.querySelector('.lightbox-close').focus();
  }
  function close() {
    box.hidden = true; document.body.classList.remove('modal-open'); img.src = '';
    if (lastTrigger) { lastTrigger.focus(); }
  }

  items.forEach(function (a, i) {
    a.addEventListener('click', function (e) { e.preventDefault(); open(i, a); });
  });
  box.querySelector('.lightbox-close').addEventListener('click', close);
  box.querySelector('.lightbox-prev').addEventListener('click', function () { show(index - 1); });
  box.querySelector('.lightbox-next').addEventListener('click', function () { show(index + 1); });
  box.addEventListener('click', function (e) { if (e.target === box) { close(); } });
  document.addEventListener('keydown', function (e) {
    if (box.hidden) { return; }
    if (e.key === 'Escape') { close(); }
    if (e.key === 'ArrowLeft') { show(index - 1); }
    if (e.key === 'ArrowRight') { show(index + 1); }
    if (e.key === 'Tab') {
      var f = box.querySelectorAll('button'); var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
})();
