// NextGen Tennis Academy — shared behaviour
document.addEventListener('DOMContentLoaded', function () {

  /* Mobile nav toggle */
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var isOpen = links.classList.toggle('open');
      toggle.classList.toggle('open', isOpen);
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    links.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        links.classList.remove('open');
        toggle.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* Highlight current page in nav */
  var current = (window.location.pathname.split('/').pop() || 'index.html');
  document.querySelectorAll('.nav-links a').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href === current || (current === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });

  /* Sticky header shadow on scroll */
  var header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.style.boxShadow = window.scrollY > 8 ? '0 8px 24px -18px rgba(0,0,0,0.6)' : 'none';
    });
  }

  /* ---------------- Enquiry form validation ---------------- */
  var form = document.getElementById('enquiry-form');
  if (form) {
    var status = document.getElementById('form-status');

    var validators = {
      fullName: function (v) { return v.trim().length >= 2 || 'Please enter your full name.'; },
      email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) || 'Please enter a valid email address.'; },
      phone: function (v) { return /^[0-9+()\-\s]{7,}$/.test(v.trim()) || 'Please enter a valid phone number.'; },
      program: function (v) { return v !== '' || 'Please select a program.'; },
      participantAge: function (v) { return (v.trim() !== '' && Number(v) > 0 && Number(v) < 100) || 'Please enter a valid age.'; },
      consent: function (v, el) { return el.checked || 'Please confirm you agree to be contacted.'; }
    };

    function fieldWrap(el) { return el.closest('.field') || el.closest('.checkbox-field').parentElement; }

    function showError(el, msg) {
      var wrap = el.closest('.field');
      if (!wrap) return;
      wrap.classList.add('error');
      var msgEl = wrap.querySelector('.error-msg');
      if (msgEl) msgEl.textContent = msg;
    }

    function clearError(el) {
      var wrap = el.closest('.field');
      if (!wrap) return;
      wrap.classList.remove('error');
      var msgEl = wrap.querySelector('.error-msg');
      if (msgEl) msgEl.textContent = '';
    }

    function validateField(el) {
      var name = el.name;
      if (!validators[name]) return true;
      var value = el.type === 'checkbox' ? el.checked : el.value;
      var result = validators[name](value, el);
      if (result === true) {
        clearError(el);
        return true;
      } else {
        showError(el, result);
        return false;
      }
    }

    Array.prototype.forEach.call(form.elements, function (el) {
      if (!validators[el.name]) return;
      var evt = (el.tagName === 'SELECT' || el.type === 'checkbox') ? 'change' : 'blur';
      el.addEventListener(evt, function () { validateField(el); });
      el.addEventListener('input', function () {
        if (el.closest('.field') && el.closest('.field').classList.contains('error')) {
          validateField(el);
        }
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var valid = true;
      Array.prototype.forEach.call(form.elements, function (el) {
        if (validators[el.name]) {
          if (!validateField(el)) valid = false;
        }
      });

      status.classList.remove('show', 'success', 'fail');

      if (!valid) {
        status.textContent = 'Please correct the highlighted fields and try again.';
        status.classList.add('show', 'fail');
        status.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }

      // No backend is connected yet — simulate a successful submission
      // so the flow can be reviewed end-to-end.
      var submitBtn = form.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending…';

      setTimeout(function () {
        status.textContent = 'Thank you — your enquiry has been received. A member of our team will contact you within 1–2 business days.';
        status.classList.add('show', 'success');
        status.scrollIntoView({ behavior: 'smooth', block: 'center' });
        form.reset();
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit Enquiry';
      }, 800);
    });
  }

});
