# NextGen Tennis Academy — Website (WEDE5020 POE)

**Student:** Neo Mogola (ST10522165) · **Group:** DIS Group 3
**Subject:** Web Development (WEDE5020)

A responsive, multi-page marketing and enquiry website for a fictional high-performance tennis academy, built with semantic HTML5, a single external CSS stylesheet, and vanilla JavaScript.

## Pages

| Page | File | Purpose |
|---|---|---|
| Home | `index.html` | Hero, programs preview, why-NextGen pillars, CTA |
| About | `about.html` | History, mission/vision, values, coaching staff |
| Services | `services.html` | Junior/adult/private programs, membership pricing, contracts |
| Enquiry | `enquiry.html` | Validated enquiry/booking form |
| Contact | `contact.html` | Location details, embedded maps, operating hours |

## Tech

- Semantic HTML5 across all pages, shared header/nav/footer
- One external stylesheet: `css/style.css` (design tokens via CSS custom properties, Flexbox + CSS Grid layouts, typography scale, hover/focus/active states)
- Responsive breakpoints at 940px / 880px / 780px / 640px / 620px / 520px, using relative units (`rem`, `%`, `clamp()`) throughout
- Responsive image via `<picture>` + `srcset`/`sizes` on `about.html`
- `js/main.js` — mobile nav toggle, active-page highlighting, sticky header shadow, enquiry form validation

## Changelog

All entries below reflect this pass — no formal marked feedback had been received for Part 1 at the time of writing, so these are self-review edits made against the Part 2 brief's own learning outcomes (external stylesheet discipline, cascading/selector efficiency, responsive images), rather than corrections to specific lecturer comments.

### 2026-09-18
- **Added a responsive image** (`about.html`, new "action photo" section): implemented with a `<picture>` element, a mobile-specific `<source>`, and a 3-candidate `srcset`/`sizes` set on the fallback `<img>`, satisfying the brief's requirement to demonstrate responsive image techniques. No photographic images existed anywhere in the Part 1 site (icons/decoration were inline SVG only), so this was a genuine gap rather than a refinement.
- **Consolidated all page-specific CSS into the single external stylesheet.** `services.html` previously carried its own `<style>` block (`.price-card`, `.program-row` rules) in the document `<head>`, in addition to the shared `css/style.css` link. Moved that block into `style.css` so every page now styles exclusively from one linked stylesheet, as the brief specifies.
- **Reduced inline styling in favour of the CSS cascade**, per the brief's explicit outcome to "take advantage of the cascading nature of CSS to style page elements with a minimum number of selectors":
  - Replaced repeated inline `background`/`border`/`color` combinations on `.card` elements (`index.html`, `about.html`) with reusable modifier classes: `.card-mist`, `.card-navy`, `.card-navy-soft`.
  - Replaced a repeated inline light-CTA-banner override (`services.html`) with a `.cta-banner-light` class.
  - Added a `.bg-navy p{ color: var(--muted-on-navy); }` rule so paragraph text on dark sections is legible by default, removing the need for a per-paragraph inline colour override (previously applied inconsistently — some navy sections used the override, some didn't).
  - Replaced a 3× repeated inline circular-avatar style block (`about.html`, coaching staff cards) with a single `.avatar-circle` class.
  - Replaced a 6× repeated inline flex/SVG pattern for checkmark list items (`services.html`, Adult Leagues and Private Lessons) with `.check-list` / `.check-icon` classes.
  - Removed an inline `color:var(--white)` on the footer brand text (present identically on all 5 pages) — it was already redundant, since `.brand` sets that colour and the span inherits it; also removed a matching redundant `margin-bottom` override on the footer brand link, now handled by a single `.footer-brand .brand` rule.
- **Net effect:** no visual or functional change to any page — this pass only reorganised *how* the existing design is expressed in CSS, so a future colour or spacing change only needs to happen in one place instead of being repeated across files.

### Prior to this pass (Part 1 submission)
- Initial build of all 5 pages, design tokens, base/typography/layout styles, responsive breakpoints, and enquiry form validation logic.

## Testing

> Screenshot evidence of desktop / tablet / mobile views to be added here before submission — see `docs/screenshots/` (create this folder and reference each image, e.g. `![Home — desktop](docs/screenshots/home-desktop.png)`).

Tested manually using browser developer tools' device toolbar across the following widths:
- Desktop: 1440px, 1200px
- Tablet: 820px, 768px
- Mobile: 414px, 375px

## References

- MDN Web Docs. *CSS Grid Layout.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs. *Flexbox.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- MDN Web Docs. *Responsive images.* https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- MDN Web Docs. *Using media queries.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
- MDN Web Docs. *CSS values and units.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Values_and_Units
- Google Fonts. *Inter* and *Manrope* typefaces. https://fonts.google.com/
- W3C. *Web Content Accessibility Guidelines (WCAG) 2.1.* https://www.w3.org/TR/WCAG21/

## Repository

GitHub repository link: _add link here before submitting to the LMS_
